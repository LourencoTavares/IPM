class Target
{
  constructor(x, y, w, l, id)
  {
    this.x = x;
    this.y = y;
    this.width = w;
    this.label = l;
    this.id = id;
    this.selected = false;
  }
  
  clicked(mouse_x, mouse_y)
  {
    let w = this.width * 1.4;
    let h = this.width * 0.9;

    if (mouse_x > this.x - w/2 &&
        mouse_x < this.x + w/2 &&
        mouse_y > this.y - h/2 &&
        mouse_y < this.y + h/2)
    {
      this.selected = true;
      return true;
    }
    return false;
  }
  
  draw()
  {
    push();

    rectMode(CENTER);

    let w = this.width * 1.4;
    let h = this.width * 0.9;

    let hover = mouseX > this.x - w/2 &&
                mouseX < this.x + w/2 &&
                mouseY > this.y - h/2 &&
                mouseY < this.y + h/2;

    noStroke();

    if (this.selected)
    {
      fill(150);
    }
    else if (hover)
    {
      stroke(255, 255, 255, 40);
      strokeWeight(20);
      noFill();

      stroke(255, 255, 255, 100);
      strokeWeight(12);
      let w = this.width * 1.4;
      let h = this.width * 0.9;

      rect(this.x, this.y, w + 20, h + 20, 12);
      rect(this.x, this.y, w + 10, h + 10, 10);
      stroke(255);
      strokeWeight(5);
      fill(255);
    }
    else
    {
      fill(corPorInicial(this.label));
    }

    noStroke();

    rect(this.x, this.y, w, h, 10);
    textAlign(CENTER);

    let primeiras = this.label[0] + this.label[1] + this.label[2];

    textFont("Arial", 40);
    textStyle(BOLD);
    fill(0);
    text(primeiras, this.x, this.y );

    if (this.selected)
    {
      textFont("Arial", 20);
      textStyle(NORMAL);
    }
    else if (hover)
    {
      textFont("Arial", 20);
      textStyle(BOLD);
    }
    else
    {
      textFont("Arial", 20);
      textStyle(NORMAL);
    }

    fill(0);
    text(this.label, this.x, this.y + 20);
    pop();
  }
}